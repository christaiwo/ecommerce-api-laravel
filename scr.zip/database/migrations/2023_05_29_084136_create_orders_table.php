<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onUpdate('restrict')->onDelete('cascade');
            $table->foreignId('address_id')->constrained()->onUpdate('restrict')->onDelete('cascade');
            $table->string('hash')->unique();
            $table->string('amount')->default(0);
            $table->string('payment_method')->nullable();
            $table->integer('status')->default(0)->comment('0=pending,1=paid,2=cancelled');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
